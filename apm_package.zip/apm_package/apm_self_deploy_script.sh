#!/bin/bash
#This is a common file to call prometheus exporters - Java, Node and HTTProxy
#input1=$1
#input2=$2
apm_home=/usr/local/raja_apm
rd_exchange_uri=$1

# For future use to develop START, STATUS and STOP code

# Self deploying started
# First boot actions executing
# Verifying dependencies
go_flag=$(echo `go version` | grep version | wc -c)

if $go_flag == 0; then
  echo "GO compiler not found. Installing the dependency."
  `sudo yum install go`
else
  echo `go version`
fi

java_flag=$(echo `java -version` | grep version | wc -c)
if $java_flag == 0; then
  echo "JAVA not installed. Installing the dependency."
  `sudo yum install java`
else
  echo `java -version`
fi

# create target directorie(s) for APM agent
mkdir -p $apm_home

# Unpacking the APM package to target directory - /usr/local/raja_apm
cd $apm_home
mv /usr/tmp/raja_apm_package.tar .
tar -x raja_apm_package.tar

# Starting Node exporter
cd node_exporter
./node_exporter > $apm_home/node_exporter/logs/node_exporter_`date +%d%m%Y%H%M%S`.log 2>&1 &


# Starting java exporter
#cd ../jmx_exporter
#java -javaagent:./jmx_prometheus_javaagent-0.11.0.jar=8888:config.yaml -jar <rd_exchange_be_location> > $apm_home/jmx_exporter/logs/jmx_exporter_`date +%d%m%Y%H%M%S`.log 2>&1 &

# Starting HAPROXY exporter
cd ../haproxy_exporter
./haproxy_exporter --haproxy.scrape-uri="http://rd_exchange_uri:3000/haproxy?stats;csv" > $apm_home/haproxy_exporter/logs/http_exporter_`date +%d%m%Y%H%M%S`.log 2>&1 &
